﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double suma = 0;
        int cantidadNotas = 5;

        Console.WriteLine("PROMEDIO DE NOTAS");

        for (int i = 1; i <= cantidadNotas; i++)
        {
            bool notaValida = false;

            while (!notaValida)
            {
                try
                {
                    Console.Write($"Ingrese la nota #{i}: ");
                    double nota = Convert.ToDouble(Console.ReadLine());

                    // Validar que la nota esté entre 0 y 100
                    if (nota < 0 || nota > 100)
                    {
                        throw new Exception("La nota debe estar entre 0 y 100.");
                    }

                    suma += nota;
                    notaValida = true;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Error: Debe ingresar un número válido.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
            }
        }

        try
        {
            if (cantidadNotas == 0)
            {
                throw new DivideByZeroException("No se puede dividir entre cero.");
            }

            double promedio = suma / cantidadNotas;

            Console.WriteLine("\n=== RESULTADO ===");
            Console.WriteLine($"La suma total es: {suma}");
            Console.WriteLine($"El promedio es: {promedio}");
        }
        catch (DivideByZeroException ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }
        catch (Exception ex)
        {
            Console.WriteLine("Ocurrió un error inesperado: " + ex.Message);
        }

        Console.WriteLine("\nPresione una tecla para salir...");
        Console.ReadKey();
    }
}
